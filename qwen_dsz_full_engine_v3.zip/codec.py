# DSZ Codec Module
print("Codec module loaded.")
