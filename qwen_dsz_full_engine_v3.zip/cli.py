# DSZ Command Line Interface
print("CLI loaded.")
