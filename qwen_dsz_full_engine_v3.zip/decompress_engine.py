# Standalone High-Performance DSZ Parallel Decompression Engine
import numpy as np
import bz2
import zlib
from concurrent.futures import ThreadPoolExecutor

def decompress_stream_chunk(chunk_data, codebook, block_size=256):
    indices = []
    for byte in chunk_data:
        indices.append(byte >> 4)
        indices.append(byte & 15)
    return np.array([codebook[idx] for idx in indices], dtype=np.float32).flatten()

def decompress_payload_parallel(payload_path, output_shape, block_size=256, codebook_size=16, max_workers=16):
    with open(payload_path, 'rb') as f:
        raw_data = f.read()
    zlib_decompressor = zlib.decompressobj()
    decompressed_cb = zlib_decompressor.decompress(raw_data)
    unused_data = zlib_decompressor.unused_data
    if not unused_data:
        idx = raw_data.find(b'BZh9')
        if idx != -1:
            unused_data = raw_data[idx:]

    cb_total_bytes = codebook_size * block_size
    quantized_cb = np.frombuffer(decompressed_cb[:cb_total_bytes], dtype=np.uint8).reshape((codebook_size, block_size))
    cb_min, cb_max = -3.5, 3.5
    codebook = (quantized_cb.astype(np.float32) / 255.0) * (cb_max - cb_min) + cb_min

    indices_payload = bz2.decompress(unused_data)
    chunk_size = max(1024, len(indices_payload) // max_workers)
    payload_chunks = [indices_payload[i:i+chunk_size] for i in range(0, len(indices_payload), chunk_size)]

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(decompress_stream_chunk, chunk, codebook, block_size) for chunk in payload_chunks]
        results = [f.result() for f in futures]

    return np.concatenate(results)[:np.prod(output_shape)].reshape(output_shape)
