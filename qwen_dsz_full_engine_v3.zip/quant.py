# DSZ Quantization Module
import numpy as np

def pack_bits(quantized_array, bits):
    if bits == 8:
        return quantized_array.tobytes()
    packed = []
    val = 0
    shift = 0
    for x in quantized_array:
        val |= (int(x) & ((1 << bits) - 1)) << shift
        shift += bits
        if shift >= 8:
            packed.append(val & 255)
            val = 0
            shift = 0
    if shift > 0:
        packed.append(val & 255)
    return bytes(packed)
